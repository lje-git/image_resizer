document.addEventListener('DOMContentLoaded', () => {
    const dropArea = document.getElementById('drop-area');
    const fileElem = document.getElementById('fileElem');
    const fileListDiv = document.getElementById('file-list');
    const processButton = document.getElementById('processButton');
    const clearButton = document.getElementById('clearButton');
    const downloadAllButton = document.getElementById('downloadAllButton');
    const targetDimensionSlider = document.getElementById('targetDimension');
    const targetDimensionValueSpan = document.getElementById('targetDimensionValue');
    const qualityPresetSelect = document.getElementById('qualityPreset');
    const fileCountSpan = document.getElementById('file-count');

    const overallProgressContainer = document.getElementById('overall-progress-container');
    const overallProgressBar = document.getElementById('overall-progress');
    const overallProgressText = document.getElementById('overall-progress-text');

    const totalSavingsDiv = document.getElementById('total-savings');
    const totalOriginalSizeSpan = document.getElementById('totalOriginalSize');
    const totalOptimizedSizeSpan = document.getElementById('totalOptimizedSize');
    const totalSavingsPercentageSpan = document.getElementById('totalSavingsPercentage');

    let filesToProcess = [];
    let processedFilesData = [];

    // --- Drag and Drop ---
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        dropArea.addEventListener(eventName, preventDefaults, false);
    });

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    ['dragenter', 'dragover'].forEach(eventName => {
        dropArea.addEventListener(eventName, () => dropArea.classList.add('highlight'), false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        dropArea.addEventListener(eventName, () => dropArea.classList.remove('highlight'), false);
    });

    dropArea.addEventListener('drop', handleDrop, false);
    fileElem.addEventListener('change', handleFileSelect);

    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        handleFiles(files);
    }

    function handleFileSelect(e) {
        const files = e.target.files;
        handleFiles(files);
    }

    function handleFiles(inputFiles) {
        const newFiles = Array.from(inputFiles).filter(file =>
            ['image/jpeg', 'image/png', 'image/webp', 'image/avif'].includes(file.type) &&
            !filesToProcess.find(f => f.id === `${file.name}-${file.lastModified}`)
        );

        newFiles.forEach(file => {
            const fileEntry = {
                id: `${file.name}-${file.lastModified}`,
                file: file,
                originalName: file.name,
                originalSize: file.size,
                status: 'Waiting',
                element: null,
                processedBlob: null,
                newSize: null,
                errorMessage: null,
                sizeWarning: null
            };
            filesToProcess.push(fileEntry);
            addFileToListUI(fileEntry);
        });
        updateFileCountAndButtons();
    }

    function updateFileCountAndButtons() {
        fileCountSpan.textContent = `${filesToProcess.length} file(s) selected`;
        const hasFiles = filesToProcess.length > 0;
        processButton.disabled = !hasFiles;
        clearButton.disabled = !hasFiles;
        if (!hasFiles) {
            downloadAllButton.style.display = 'none';
            overallProgressContainer.style.display = 'none';
            totalSavingsDiv.style.display = 'none';
        }
    }

    function formatBytes(bytes, decimals = 2) {
        if (bytes === 0 || !bytes) return '0 Bytes';
        const k = 1024;
        const dm = decimals < 0 ? 0 : decimals;
        const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
    }

    function addFileToListUI(fileEntry) {
        const item = document.createElement('div');
        item.classList.add('file-item');
        item.id = `file-${fileEntry.id}`;
        item.innerHTML = `
            <div class="file-info">
                <strong>${fileEntry.originalName}</strong>
                <div class="file-meta">
                    <span class="original-size">Original: ${formatBytes(fileEntry.originalSize)}</span>
                    <span class="optimized-size"></span>
                    <span class="error-message"></span>
                    <span class="size-warning" style="color: orange; font-size:0.8em"></span>
                </div>
            </div>
            <div class="file-status waiting">${fileEntry.status}</div>
            <div class="file-actions"></div>
        `;
        fileEntry.element = item;
        fileListDiv.appendChild(item);
    }

    function updateFileUI(fileEntry) {
        const item = fileEntry.element;
        if (!item) return;

        item.querySelector('.file-status').textContent = fileEntry.status;
        item.querySelector('.file-status').className = `file-status ${fileEntry.status.toLowerCase()}`;

        const optimizedSizeSpan = item.querySelector('.optimized-size');
        if (fileEntry.newSize) {
            optimizedSizeSpan.textContent = `Optimized: ${formatBytes(fileEntry.newSize)}`;
            if (fileEntry.newSize < fileEntry.originalSize) {
                 optimizedSizeSpan.style.color = 'green';
            } else if (fileEntry.newSize > fileEntry.originalSize) {
                 optimizedSizeSpan.style.color = 'orange';
            } else {
                optimizedSizeSpan.style.color = 'inherit';
            }
        } else {
            optimizedSizeSpan.textContent = '';
        }

        item.querySelector('.error-message').textContent = fileEntry.errorMessage || '';
        item.querySelector('.size-warning').textContent = fileEntry.sizeWarning || '';

        const actionsDiv = item.querySelector('.file-actions');
        actionsDiv.innerHTML = '';

        if (fileEntry.processedBlob && fileEntry.status === 'Done') {
            const downloadLink = document.createElement('a');
            downloadLink.href = URL.createObjectURL(fileEntry.processedBlob);
            downloadLink.download = fileEntry.originalName;
            downloadLink.textContent = 'Save Image';
            actionsDiv.appendChild(downloadLink);
        }
    }

    targetDimensionSlider.addEventListener('input', (e) => {
        targetDimensionValueSpan.textContent = e.target.value;
    });

    processButton.addEventListener('click', async () => {
        if (filesToProcess.length === 0) return;

        processButton.disabled = true;
        clearButton.disabled = true;
        downloadAllButton.style.display = 'none';
        overallProgressContainer.style.display = 'block';
        overallProgressBar.value = 0;
        overallProgressText.textContent = '0%';
        processedFilesData = [];
        totalSavingsDiv.style.display = 'none';

        let processedCount = 0;
        const totalFiles = filesToProcess.length;
        const CONCURRENCY_LIMIT = 5;
        let currentProcessing = 0;
        let fileIndex = 0;

        const processQueue = async () => {
            while(fileIndex < totalFiles) {
                if (currentProcessing < CONCURRENCY_LIMIT) {
                    currentProcessing++;
                    const entry = filesToProcess[fileIndex++];
                    entry.status = 'Processing';
                    updateFileUI(entry);

                    processSingleImage(entry)
                        .catch((error) => {
                            console.error(`Error processing ${entry.originalName}:`, error);
                            entry.status = 'Error';
                            entry.errorMessage = error.message || 'Processing failed.';
                            updateFileUI(entry);
                        })
                        .finally(() => {
                            currentProcessing--;
                            processedCount++;
                            const progress = Math.round((processedCount / totalFiles) * 100);
                            overallProgressBar.value = progress;
                            overallProgressText.textContent = `${progress}%`;
                            if (processedCount === totalFiles) {
                                onAllFilesProcessed();
                            }
                            if (fileIndex < totalFiles || currentProcessing > 0) {
                                processQueue();
                            }
                        });
                } else {
                    await new Promise(resolve => setTimeout(resolve, 100));
                }
            }
        };
        processQueue();
    });

    async function processSingleImage(fileEntry) {
        try {
            const img = await loadImage(fileEntry.file);
            const targetDimension = parseInt(targetDimensionSlider.value);

            if (img.width < targetDimension && img.height < targetDimension) {
                fileEntry.sizeWarning = `Original (${img.width}x${img.height}) is smaller than target. Target: ${targetDimension}px.`;
            } else {
                fileEntry.sizeWarning = null;
            }

            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            let { width, height } = calculateNewDimensions(img.width, img.height, targetDimension);

            if (img.width <= targetDimension && img.height <= targetDimension &&
                !fileEntry.sizeWarning) {
                width = img.width;
                height = img.height;
            }

            canvas.width = width;
            canvas.height = height;
            // Browsers handle image orientation by default before drawing to canvas
            ctx.drawImage(img, 0, 0, width, height);

            const qualityPreset = qualityPresetSelect.value;
            let mimeType = fileEntry.file.type;
            let quality;

            switch (mimeType) {
                case 'image/jpeg':
                    if (qualityPreset === 'high') quality = 0.92;
                    else if (qualityPreset === 'balanced') quality = 0.85;
                    else quality = 0.75;
                    break;
                case 'image/webp':
                    mimeType = 'image/webp';
                    if (qualityPreset === 'high') quality = 0.90;
                    else if (qualityPreset === 'balanced') quality = 0.80;
                    else quality = 0.70;
                    break;
                case 'image/avif':
                     // AVIF encoding support via canvas.toBlob is still somewhat limited
                    mimeType = 'image/avif';
                    if (qualityPreset === 'high') quality = 0.80;
                    else if (qualityPreset === 'balanced') quality = 0.65;
                    else quality = 0.50;
                    break;
                case 'image/png':
                    quality = undefined; // PNG is lossless via canvas, quality ignored
                    break;
                default:
                    throw new Error('Unsupported image type for processing.');
            }

            const blob = await new Promise((resolveBlob, rejectBlob) => {
                canvas.toBlob(
                    (b) => {
                        if (b) resolveBlob(b);
                        else rejectBlob(new Error('Canvas toBlob returned null. Check browser compatibility for AVIF encoding if applicable.'));
                    },
                    mimeType,
                    quality
                );
            });

            if (!blob) {
                throw new Error('Canvas toBlob failed to produce a blob.');
            }

            fileEntry.processedBlob = blob;
            fileEntry.newSize = fileEntry.processedBlob.size;
            fileEntry.status = 'Done';
            processedFilesData.push({
                filename: fileEntry.originalName,
                blob: fileEntry.processedBlob,
                originalSize: fileEntry.originalSize,
                newSize: fileEntry.newSize
            });
            updateFileUI(fileEntry);

        } catch (error) {
            console.error(`Error processing ${fileEntry.originalName} in processSingleImage:`, error);
            fileEntry.status = 'Error';
            fileEntry.errorMessage = error.message || 'Unknown processing error.';
            updateFileUI(fileEntry);
            throw error;
        }
    }

    function loadImage(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => {
                const img = new Image();
                img.onload = () => resolve(img);
                img.onerror = (errEvent) => {
                    console.error("Image load error event:", errEvent);
                    reject(new Error('Could not load image. It might be corrupted or an unsupported format.'));
                };
                img.src = e.target.result;
            };
            reader.onerror = (errEvent) => {
                 console.error("FileReader error event:", errEvent);
                reject(new Error('FileReader error. Could not read the file.'));
            };
            if (file) {
                reader.readAsDataURL(file);
            } else {
                reject(new Error('No file provided to loadImage.'));
            }
        });
    }

    function calculateNewDimensions(originalWidth, originalHeight, targetLongerDim) {
        let newWidth, newHeight;
        if (originalWidth > originalHeight) {
            if (originalWidth > targetLongerDim) {
                newWidth = targetLongerDim;
                newHeight = (originalHeight / originalWidth) * newWidth;
            } else {
                newWidth = originalWidth;
                newHeight = originalHeight;
            }
        } else {
            if (originalHeight > targetLongerDim) {
                newHeight = targetLongerDim;
                newWidth = (originalWidth / originalHeight) * newHeight;
            } else {
                newWidth = originalWidth;
                newHeight = originalHeight;
            }
        }
        return { width: Math.round(newWidth), height: Math.round(newHeight) };
    }

    function onAllFilesProcessed() {
        processButton.disabled = filesToProcess.length === 0;
        clearButton.disabled = filesToProcess.length === 0;

        const successfulFiles = processedFilesData.filter(f => f.blob);
        if (successfulFiles.length > 0) {
            downloadAllButton.style.display = 'inline-block';
            updateTotalSavings();
            totalSavingsDiv.style.display = 'block';
        } else {
            downloadAllButton.style.display = 'none';
            totalSavingsDiv.style.display = 'none';
        }
    }

    function updateTotalSavings() {
        let totalOriginal = 0;
        let totalOptimized = 0;
        processedFilesData.forEach(data => {
            if(data.blob) {
                totalOriginal += data.originalSize || 0;
                totalOptimized += data.newSize || 0;
            }
        });

        totalOriginalSizeSpan.textContent = formatBytes(totalOriginal);
        totalOptimizedSizeSpan.textContent = formatBytes(totalOptimized);

        if (totalOriginal > 0 && totalOptimized < totalOriginal) {
            const savings = ((totalOriginal - totalOptimized) / totalOriginal) * 100;
            totalSavingsPercentageSpan.textContent = `${savings.toFixed(1)}%`;
        } else if (totalOriginal > 0 && totalOptimized >= totalOriginal) {
            totalSavingsPercentageSpan.textContent = `0% (or larger)`;
        }
         else {
            totalSavingsPercentageSpan.textContent = '0%';
        }
    }

    downloadAllButton.addEventListener('click', () => {
        const successfulFilesToZip = processedFilesData.filter(f => f.blob);
        if (successfulFilesToZip.length === 0) return;

        const zip = new JSZip();
        successfulFilesToZip.forEach(data => {
            zip.file(data.filename, data.blob);
        });

        zip.generateAsync({ type: "blob", compression: "DEFLATE", compressionOptions: { level: 6 }})
            .then(function (content) {
                const link = document.createElement('a');
                link.href = URL.createObjectURL(content);
                link.download = "Optimized_Images_Batch.zip"; // Updated default ZIP filename
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                URL.revokeObjectURL(link.href);
            })
            .catch(err => {
                console.error("Error creating ZIP file:", err);
                alert("Error creating ZIP file. Check console for details.");
            });
    });

    clearButton.addEventListener('click', () => {
        filesToProcess.forEach(entry => {
            if (entry.processedBlob) {
                const existingLink = entry.element?.querySelector('.file-actions a');
                if (existingLink && existingLink.href.startsWith('blob:')) {
                    URL.revokeObjectURL(existingLink.href);
                }
            }
        });

        filesToProcess = [];
        processedFilesData = [];
        fileListDiv.innerHTML = '';
        updateFileCountAndButtons();
        overallProgressContainer.style.display = 'none';
        overallProgressBar.value = 0;
        overallProgressText.textContent = '0%';
        downloadAllButton.style.display = 'none';
        totalSavingsDiv.style.display = 'none';
        fileElem.value = '';
    });
});